#include <sampler.h>
#include<esp_task_wdt.h>
#include<driver/GPIO.h>
#include<driver/dac.h>
#include <driver/timer.h>
#include <freertos/FreeRTOS.h>
#include<freertos/timers.h>
#include <driver/adc.h>

int Fs;
volatile int cnt = 0;
void IRAM_ATTR timer_group0_isr(void *para){// timer group 0, ISR
    int timer_idx = (int) para;
     uint32_t intr_status = TIMERG0.int_st_timers.val;
      if((intr_status & BIT(timer_idx)) && timer_idx == TIMER_0) {
          TIMERG0.hw_timer[timer_idx].update = 1;
          TIMERG0.int_clr_timers.t0 = 1;
          TIMERG0.hw_timer[timer_idx].config.alarm_en = 1;
          gpio_set_level(GPIO_NUM_16,cnt%2);
          cnt++;
      }
}

void startSampling(int freq){



adc_power_on();
adc_gpio_init(ADC_UNIT_1, ADC1_GPIO32_CHANNEL);
adc1_config_width(ADC_WIDTH_BIT_12);
adc1_config_channel_atten(ADC1_GPIO32_CHANNEL,ADC_ATTEN_DB_11);

//esp_err_t result = gpio_pullup_en(32);

Fs = 2* freq;
int timer_idx = TIMER_0;
int timer_group = TIMER_GROUP_0;    
timer_config_t config;
config.auto_reload  = 1;
config.counter_dir = TIMER_COUNT_DOWN;
config.divider = 80;
config.intr_type = TIMER_INTR_LEVEL;
config.counter_en = TIMER_PAUSE;


/*Configure timer*/
    timer_init(timer_group, timer_idx, &config);
    /*Stop timer counter*/
    timer_pause(timer_group, timer_idx);
    /*Load counter value */
    timer_set_counter_value(timer_group, timer_idx, adc1_get_raw(ADC1_GPIO32_CHANNEL));
    /*Enable timer interrupt*/
    timer_enable_intr(timer_group, timer_idx);
    /*Set ISR handler*/
    timer_isr_register(timer_group, timer_idx, timer_group0_isr, (void*) timer_idx, ESP_INTR_FLAG_IRAM, NULL);
    /*Start timer counter*/
    timer_start(timer_group, timer_idx);
}

void stopSampling(){

}