#ifndef SAMPLER_H_
#define SAMPLER_H

void startSampling(int freq);

void stopSampling();

float getFrequency();
#endif