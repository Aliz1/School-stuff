#include <stdio.h>
#include <esp_task_wdt.h>
#include "soundgen.h"
#include "sampler.h"
#include <driver/adc.h>


void app_main()
{
while (1)
{
     startSampling(2000);
     int val = adc1_get_raw(ADC1_GPIO32_CHANNEL);
  printf("\n\n\n\n");
  printf("actual frequency is %d", val);
  printf("\n\n\n\n");
}

   //int actualfreq = startSound(0);




 

    }