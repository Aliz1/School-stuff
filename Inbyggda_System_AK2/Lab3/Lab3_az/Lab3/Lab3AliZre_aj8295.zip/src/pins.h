#ifndef PINS_H_
#define PINS_H_

#include <stdint.h>

void initPins();

void setLED(uint8_t);


#endif
