#ifndef RANDOM_H_


#define RANDOM_H_

int getRandomFrequency(int min, int max);



#endif